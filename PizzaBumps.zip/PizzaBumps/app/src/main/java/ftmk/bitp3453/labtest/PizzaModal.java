package ftmk.bitp3453.labtest;

public class PizzaModal {
    private String pizzaID, pizzaName, pizzaPrice;

    public String getPizzaID() {
        return pizzaID;
    }

    public void setPizzaID(String pizzaID) {
        this.pizzaID = pizzaID;
    }

    public String getPizzaName() {
        return pizzaName;
    }

    public void setPizzaName(String pizzaName) {
        this.pizzaName = pizzaName;
    }

    public String getPizzaPrice() {
        return pizzaPrice;
    }

    public void setPizzaPrice(String pizzaPrice) {
        this.pizzaPrice = pizzaPrice;
    }

    public PizzaModal(String pizzaID, String pizzaName, String pizzaPrice) {
        this.pizzaID = pizzaID;
        this.pizzaName = pizzaName;
        this.pizzaPrice = pizzaPrice;
    }
}
